import 'package:flutter_dotenv/flutter_dotenv.dart';

class ApiConstants {
  static const String _defaultBaseUrl = String.fromEnvironment(
    'API_BASE_URL',
    defaultValue: 'http://localhost',
  );
  static const String _defaultApiPort = String.fromEnvironment(
    'API_PORT',
    defaultValue: '4000',
  );
  static const String _defaultLmStudioPort = String.fromEnvironment(
    'LM_STUDIO_PORT',
    defaultValue: '1234',
  );

  static String _readEnv(String key, String fallback) {
    final value = dotenv.isInitialized ? dotenv.env[key]?.trim() : null;
    if (value == null || value.isEmpty) {
      return fallback;
    }
    return value;
  }

  static String get baseUrl => _readEnv('API_BASE_URL', _defaultBaseUrl);

  static String get apiPort => _readEnv('API_PORT', _defaultApiPort);

  static String get lmStudioPort =>
      _readEnv('LM_STUDIO_PORT', _defaultLmStudioPort);

  static String get authUrl => baseUrl;

  static String get lmStudioUrl => baseUrl;
}
